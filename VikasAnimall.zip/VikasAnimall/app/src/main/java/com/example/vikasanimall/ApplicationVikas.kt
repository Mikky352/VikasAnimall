package com.example.vikasanimall

import android.app.Application

class ApplicationVikas: Application() {


    override fun onCreate() {
        super.onCreate()
    }





}